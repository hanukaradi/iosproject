//
//  SHAppDelegate.h
//  StatusBarTest
//
//  Created by hanumantha rao on 14/07/14.
//  Copyright (c) 2014 hanumantha rao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JDAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
