//
//  JDMenuViewController.h
//  JDSideMenu
//
//  Created by hanumantha rao on 14.07.14.
//  Copyright (c) 2014 hanumantha rao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JDMenuViewController : UIViewController

@end
