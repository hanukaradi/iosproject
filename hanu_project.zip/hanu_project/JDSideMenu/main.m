//
//  main.m
//  JDSideMenu
//
//  Created by hanumantha rao on 14.07.14.
//  Copyright (c) 2014 hanumantha rao. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "JDAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([JDAppDelegate class]));
    }
}
