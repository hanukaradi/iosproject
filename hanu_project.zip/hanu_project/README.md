JDSideMenu
==========

A basic implementation of a side menu Controller.
It moves the ios7 Statusbar to the right toghether with the controller to reveal a menu underneath.

![Screenshots](gfx/screenshots.png)


